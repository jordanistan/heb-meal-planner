class _Settings:
    heb_search_url = "https://www.heb.com/search/?q={query}"
settings = _Settings()
