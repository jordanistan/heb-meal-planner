"""Inline-SVG charts for the printable reports (no JavaScript, print-safe).

Each function returns an <svg> string sized by a viewBox, so it scales to the
page width and prints crisply. Hover tooltips use SVG <title>; every chart's
numbers also appear in a table elsewhere in the report.

Colors are the validated categorical slots 1–3 (blue, orange, aqua) on a white
surface; text always uses ink tokens, never the series color.
"""
from __future__ import annotations

from datetime import date
from html import escape

SERIES = ("#2a78d6", "#eb6834", "#1baf7a")
INK = "#0b0b0b"
INK_2 = "#52514e"
MUTED = "#898781"
GRID = "#e1e0d9"
AXIS = "#c3c2b7"
SURFACE = "#ffffff"

W = 720  # default viewBox width; height varies per chart
SMALL_W = 360  # small multiples: drawn narrow so text keeps its size
PAD_L, PAD_T, PAD_B = 48, 26, 34
PAD_R = 78  # right margin holds reference-line labels, clear of the bars
GAP = 2  # surface gap between touching segments


def _ticks(peak: float, target: int = 4) -> tuple[float, int]:
    """A clean tick step (1/2/5 × 10^n) and tick count covering `peak`."""
    peak = max(peak, 1)
    raw = peak / target
    mag = 10 ** (len(str(int(raw))) - 1) if raw >= 1 else 1
    step = next(m * mag for m in (1, 2, 5, 10) if m * mag >= raw)
    count = int(-(-peak // step))  # ceil
    return step, max(count, 1)


def _fmt(v: float) -> str:
    return f"{v / 1000:.1f}K".replace(".0K", "K") if v >= 1000 else f"{v:g}"


def _bar_path(x: float, y: float, w: float, h: float, r: float = 4) -> str:
    """Rect with rounded top corners (data end), square at the baseline."""
    r = min(r, w / 2, h)
    return (
        f"M{x:.1f},{y + h:.1f} V{y + r:.1f} Q{x:.1f},{y:.1f} {x + r:.1f},{y:.1f} "
        f"H{x + w - r:.1f} Q{x + w:.1f},{y:.1f} {x + w:.1f},{y + r:.1f} V{y + h:.1f} Z"
    )


def _axis(h: float, step: float, count: int, unit: str, w: float) -> str:
    """Horizontal hairline gridlines with clean tick labels."""
    plot_h = h - PAD_T - PAD_B
    out = []
    for i in range(count + 1):
        v = step * i
        y = PAD_T + plot_h - plot_h * i / count
        color = AXIS if i == 0 else GRID
        out.append(f'<line x1="{PAD_L}" x2="{w - PAD_R}" y1="{y:.1f}" y2="{y:.1f}" stroke="{color}" stroke-width="1"/>')
        out.append(
            f'<text x="{PAD_L - 6}" y="{y + 4:.1f}" text-anchor="end" font-size="11" '
            f'fill="{MUTED}" style="font-variant-numeric:tabular-nums">{_fmt(v)}</text>'
        )
    if unit:
        out.append(f'<text x="{PAD_L - 6}" y="9" text-anchor="end" font-size="10" fill="{MUTED}">{escape(unit)}</text>')
    return "".join(out)


def _ref_line(value: float, top: float, h: float, label: str, w: float) -> str:
    """Reference line with its label in the right margin (never over a bar)."""
    plot_h = h - PAD_T - PAD_B
    y = PAD_T + plot_h - plot_h * min(value, top) / top
    lines = label.split(" ", 1)
    text = "".join(
        f'<tspan x="{w - PAD_R + 6}" dy="{0 if i == 0 else 13}">{escape(t)}</tspan>'
        for i, t in enumerate(lines)
    )
    return (
        f'<line x1="{PAD_L}" x2="{w - PAD_R}" y1="{y:.1f}" y2="{y:.1f}" stroke="{INK}" stroke-width="1.5"/>'
        f'<text y="{y - (2 if len(lines) > 1 else -4):.1f}" font-size="11" font-weight="600" fill="{INK}">{text}</text>'
    )


def _x_labels(dates: list[date], h: float, band: float, narrow: bool = False) -> str:
    if narrow:
        every = 1 if len(dates) <= 7 else (2 if len(dates) <= 14 else 7)
    else:
        every = 1 if len(dates) <= 14 else (2 if len(dates) <= 31 else 7)
    out = []
    for i, d in enumerate(dates):
        if i % every:
            continue
        x = PAD_L + band * (i + 0.5)
        label = (f"{d:%a}" if narrow else f"{d:%a} {d.day}") if len(dates) <= 7 or (not narrow and len(dates) <= 14) else f"{d:%b} {d.day}"
        out.append(f'<text x="{x:.1f}" y="{h - 12}" text-anchor="middle" font-size="11" fill="{MUTED}">{label}</text>')
    return "".join(out)


def _svg(h: float, body: str, label: str, w: float = W) -> str:
    return (
        f'<svg viewBox="0 0 {w} {h}" width="100%" role="img" aria-label="{escape(label)}" '
        f'style="font-family:system-ui,-apple-system,\'Segoe UI\',sans-serif;max-width:{w}px">{body}</svg>'
    )


def legend(items: list[tuple[str, str]]) -> str:
    """HTML legend: colored swatch + ink text."""
    return '<div class="legend">' + "".join(
        f'<span><i style="background:{c}"></i>{escape(t)}</span>' for c, t in items
    ) + "</div>"


def daily_calories(days: list[dict], goal: float | None = None) -> str:
    """Stacked columns: each day's calories split by protein / carbs / fat."""
    dates = [d["date"] for d in days]
    h = 270
    plot_h = h - PAD_T - PAD_B
    peak = max([d["totals"]["calories"] for d in days] + [goal or 0, 1])
    step, count = _ticks(peak * 1.1)
    top = step * count
    band = (W - PAD_L - PAD_R) / max(len(days), 1)
    bw = min(24, band * 0.62)
    label_caps = len(days) <= 14
    body = [_axis(h, step, count, "cal", W)]
    for i, d in enumerate(days):
        t = d["totals"]
        cal = t["calories"]
        x = PAD_L + band * (i + 0.5) - bw / 2
        if not d["entries"]:
            body.append(
                f'<text x="{x + bw / 2:.1f}" y="{PAD_T + plot_h - 6}" text-anchor="middle" '
                f'font-size="10" fill="{MUTED}">–</text>'
            )
            continue
        kcal = [t["protein_g"] * 4, t["carbs_g"] * 4, t["fat_g"] * 9]
        total_macro = sum(kcal) or 1
        y = PAD_T + plot_h
        segs = []
        for j, part in enumerate(kcal):
            seg_h = plot_h * (cal * part / total_macro) / top
            if seg_h <= 0:
                continue
            y -= seg_h
            draw_h = max(seg_h - GAP, 0.5)  # 2px surface gap above each segment
            is_top = j == 2 or all(k <= 0 for k in kcal[j + 1:])
            if is_top:
                segs.append(f'<path d="{_bar_path(x, y + GAP, bw, draw_h)}" fill="{SERIES[j]}"/>')
            else:
                segs.append(f'<rect x="{x:.1f}" y="{y + GAP:.1f}" width="{bw:.1f}" height="{draw_h:.1f}" fill="{SERIES[j]}"/>')
        pct = [round(100 * k / total_macro) for k in kcal]
        tip = (
            f"{d['date']:%a %b} {d['date'].day}: {cal:g} calories — protein {pct[0]}%, "
            f"carbs {pct[1]}%, fat {pct[2]}%"
        )
        cap = (
            f'<text x="{x + bw / 2:.1f}" y="{y - 4:.1f}" text-anchor="middle" font-size="11" '
            f'fill="{INK_2}" paint-order="stroke" stroke="{SURFACE}" stroke-width="3" '
            f'style="font-variant-numeric:tabular-nums">{round(cal):,}</text>'
            if label_caps else ""
        )
        body.append(f"<g><title>{escape(tip)}</title>{''.join(segs)}"
                    f'<rect x="{x - 4:.1f}" y="{PAD_T}" width="{bw + 8:.1f}" height="{plot_h}" fill="transparent"/>'
                    f"{cap}</g>")
    if goal:
        body.append(_ref_line(goal, top, h, f"Goal {round(goal):,}", W))
    body.append(_x_labels(dates, h, band))
    return _svg(h, "".join(body), "Daily calories by source")


def daily_metric(
    days: list[dict], key: str, unit: str, ref: float | None, ref_label: str
) -> str:
    """Single-series columns for one nutrient per day, with a guideline line."""
    dates = [d["date"] for d in days]
    w = SMALL_W
    h = 190
    plot_h = h - PAD_T - PAD_B
    values = [d["totals"][key] if d["entries"] else None for d in days]
    step, count = _ticks(max([v or 0 for v in values] + [(ref or 0) * 1.1, 1]) * 1.05, 3)
    top = step * count
    band = (w - PAD_L - PAD_R) / max(len(days), 1)
    bw = min(16, band * 0.62)
    body = [_axis(h, step, count, "", w)]  # the figure caption names the unit
    for i, v in enumerate(values):
        x = PAD_L + band * (i + 0.5) - bw / 2
        if v is None:
            body.append(f'<text x="{x + bw / 2:.1f}" y="{PAD_T + plot_h - 6}" text-anchor="middle" font-size="10" fill="{MUTED}">–</text>')
            continue
        bh = plot_h * v / top
        y = PAD_T + plot_h - bh
        tip = f"{dates[i]:%a %b} {dates[i].day}: {v:g}{unit}"
        body.append(
            f"<g><title>{escape(tip)}</title>"
            + (f'<path d="{_bar_path(x, y, bw, bh)}" fill="{SERIES[0]}"/>' if bh > 0 else "")
            + f'<rect x="{x - 4:.1f}" y="{PAD_T}" width="{bw + 8:.1f}" height="{plot_h}" fill="transparent"/></g>'
        )
    if ref:
        body.append(_ref_line(ref, top, h, ref_label, w))
    body.append(_x_labels(dates, h, band, narrow=True))
    return _svg(h, "".join(body), f"Daily {key}", w)


def horizontal_bars(rows: list[tuple[str, float]], unit: str = "") -> str:
    """Single-series horizontal bars with the value at the tip."""
    if not rows:
        return ""
    row_h, label_w = 30, 110
    h = row_h * len(rows) + 8
    top = max(v for _, v in rows) or 1
    span = W - label_w - 80
    body = []
    for i, (name, v) in enumerate(rows):
        y = 4 + i * row_h
        bw = span * v / top
        body.append(
            f'<text x="{label_w - 8}" y="{y + 17}" text-anchor="end" font-size="12" fill="{INK_2}">{escape(name)}</text>'
            f"<g><title>{escape(name)}: {v:g}{unit}</title>"
            # Horizontal bar: rounded at the right (data end), square at the baseline.
            f'<rect x="{label_w}" y="{y + 6}" width="{max(bw, 1):.1f}" height="16" rx="4" fill="{SERIES[0]}"/>'
            f'<rect x="{label_w}" y="{y + 6}" width="{min(4, bw):.1f}" height="16" fill="{SERIES[0]}"/></g>'
            f'<text x="{label_w + bw + 6:.1f}" y="{y + 18}" font-size="12" fill="{INK}" '
            f'style="font-variant-numeric:tabular-nums">{_fmt(round(v))}{unit}</text>'
        )
    return _svg(h, "".join(body), "Breakdown")
