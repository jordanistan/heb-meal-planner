"""Printable reports: a plan's recipe book and the food-log report for a doctor.

Both render to a single self-contained HTML page (inline CSS, no scripts)
that prints cleanly — the browser's "Save as PDF" turns it into a file to
email or bring to an appointment. The food log also exports as CSV.
"""
from __future__ import annotations

import csv
import io
from datetime import date
from html import escape

from .planning.nutrition import DAILY_VALUES, NUTRIENTS, percent_dv
from .planning.recipes import RECIPES_BY_ID, Recipe, cooking_method, stove_tip

DISCLAIMER = (
    "Nutrition values are estimates calculated from average USDA values for each "
    "ingredient and the recipe as written. Actual values vary with brands, portion "
    "sizes and cooking oil. Daily Values are based on a 2,000-calorie diet."
)

_LABELS = {
    "calories": "Calories",
    "protein_g": "Protein",
    "carbs_g": "Carbs",
    "fat_g": "Fat",
    "sat_fat_g": "Sat. fat",
    "fiber_g": "Fiber",
    "sugar_g": "Sugars",
    "sodium_mg": "Sodium",
}

_CSS = """
:root { --ink:#111; --muted:#555; --line:#ccc; --accent:#c8102e; }
* { box-sizing:border-box; }
body { font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif;
  color:var(--ink); background:#fff; margin:0; line-height:1.45; }
main { max-width: 860px; margin: 0 auto; padding: 24px 16px 48px; }
h1 { margin:0 0 4px; font-size:26px; }
h2 { margin:28px 0 8px; font-size:20px; border-bottom:2px solid var(--ink); padding-bottom:4px; }
h3 { margin:0 0 4px; font-size:18px; }
.sub, .muted { color:var(--muted); }
.meta { margin:0 0 16px; color:var(--muted); font-size:14px; }
.recipe { display:grid; grid-template-columns: 1fr 240px; gap:20px;
  border-top:1px solid var(--line); padding:18px 0; break-inside:avoid; }
.recipe ul, .recipe ol { margin:6px 0 10px; padding-left:20px; }
.recipe h4 { margin:10px 0 2px; font-size:14px; text-transform:uppercase; letter-spacing:.04em; }
.equip { display:inline-block; border:1px solid var(--line); border-radius:999px;
  padding:1px 8px; margin:0 4px 4px 0; font-size:12px; }
.adapt { background:#fff6e5; border-left:3px solid #e0a100; padding:6px 10px; margin:6px 0; font-size:14px; }
.tip { background:#eef6ff; border-left:3px solid #2b6cb0; padding:8px 12px; margin:12px 0; font-size:14px; }
.label { border:2px solid var(--ink); padding:6px 8px; font-size:13px; align-self:start; }
.label .title { font-weight:900; font-size:22px; line-height:1; margin-bottom:2px; }
.label .serv { border-bottom:8px solid var(--ink); padding-bottom:3px; }
.label .cal { display:flex; justify-content:space-between; font-weight:900; font-size:20px;
  border-bottom:4px solid var(--ink); padding:2px 0; }
.label .row { display:flex; justify-content:space-between; border-bottom:1px solid var(--ink); padding:1px 0; }
.label .row.indent { padding-left:12px; }
.label .dvhead { text-align:right; font-weight:700; font-size:11px; border-bottom:1px solid var(--ink); }
.label .foot { font-size:10px; margin-top:4px; }
table { width:100%; border-collapse:collapse; font-size:13px; margin:6px 0 10px; }
th, td { border-bottom:1px solid var(--line); padding:4px 6px; text-align:right; vertical-align:top; }
th:nth-child(-n+2), td:nth-child(-n+2) { text-align:left; }
tr.total td { font-weight:700; border-top:2px solid var(--ink); }
.over { color:var(--accent); font-weight:700; }
.ok { color:#1a7f37; font-weight:700; }
.summary { display:flex; flex-wrap:wrap; gap:10px; margin:10px 0; }
.summary div { border:1px solid var(--line); border-radius:8px; padding:8px 12px; min-width:130px; }
.summary b { display:block; font-size:20px; }
.day { break-inside:avoid; }
.note { font-style:italic; color:var(--muted); font-size:12px; }
.disclaimer { margin-top:28px; font-size:12px; color:var(--muted); }
.printbar { margin:0 0 16px; }
.printbar button { font:inherit; padding:6px 14px; border-radius:6px; border:1px solid var(--line);
  background:#f4f4f4; cursor:pointer; }
.summary small { display:block; color:var(--muted); font-size:12px; min-height:1em; }
.highlights { margin:6px 0 10px; padding-left:20px; }
.highlights li { margin-bottom:4px; }
.sub3 { margin-top:14px; }
.legend { display:flex; gap:16px; font-size:13px; color:#52514e; margin:4px 0; }
.legend i { display:inline-block; width:10px; height:10px; border-radius:2px; margin-right:6px; vertical-align:-1px; }
.cap { font-size:12px; color:var(--muted); margin:2px 0 10px; }
.multiples { display:grid; grid-template-columns:1fr 1fr; gap:8px 20px; }
.multiples figure { margin:0; break-inside:avoid; }
.multiples figcaption { font-size:13px; font-weight:600; margin:6px 0 0; }
table.left td:nth-child(n), table.left th:nth-child(n) { text-align:left; }
svg { display:block; }
.week th, .week td { text-align:left; }
@media (max-width: 640px) { .multiples { grid-template-columns:1fr; } }
@media (max-width: 640px) { .recipe { grid-template-columns: 1fr; } .tablewrap { overflow-x:auto; } }
@media print { .printbar { display:none; } main { padding:0; } h2 { break-after:avoid; } }
"""


def _page(title: str, body: str) -> str:
    return (
        "<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\">"
        "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">"
        f"<title>{escape(title)}</title><style>{_CSS}</style></head><body><main>"
        "<div class=\"printbar\"><button onclick=\"window.print()\">Print / Save as PDF</button></div>"
        f"{body}<p class=\"disclaimer\">{escape(DISCLAIMER)}</p></main></body></html>"
    )


def _day(d: date, weekday: bool = False) -> str:
    # Built by hand: strftime's %-d isn't portable.
    return (f"{d:%A}, " if weekday else "") + f"{d:%b} {d.day}, {d.year}"


def _num(v: float) -> str:
    """1.0 -> '1', 0.5 -> '1/2', 1.25 -> '1 1/4', other floats to 1 decimal."""
    whole = int(v)
    frac = round(v - whole, 2)
    names = {0.25: "1/4", 0.33: "1/3", 0.5: "1/2", 0.67: "2/3", 0.75: "3/4"}
    if frac == 0:
        return str(whole)
    if frac in names:
        return f"{whole} {names[frac]}" if whole else names[frac]
    return f"{v:.1f}"


def _unit(v: float, k: str) -> str:
    if k == "calories":
        return f"{v:g}"
    return f"{v:g}{'mg' if k == 'sodium_mg' else 'g'}"


def nutrition_label(facts: dict, serving_text: str) -> str:
    dv = percent_dv(facts)

    def row(key: str, indent: bool = False) -> str:
        pct = f"<b>{dv[key]}%</b>" if key in DAILY_VALUES else ""
        cls = "row indent" if indent else "row"
        name = _LABELS[key] if indent else f"<b>{_LABELS[key]}</b>"
        return (
            f"<div class=\"{cls}\"><span>{name} {_unit(facts.get(key, 0), key)}</span>"
            f"<span>{pct}</span></div>"
        )

    return (
        "<div class=\"label\"><div class=\"title\">Nutrition Facts</div>"
        f"<div class=\"serv\">{escape(serving_text)}</div>"
        f"<div class=\"cal\"><span>Calories</span><span>{facts.get('calories', 0):g}</span></div>"
        "<div class=\"dvhead\">% Daily Value*</div>"
        + row("fat_g") + row("sat_fat_g", True) + row("sodium_mg")
        + row("carbs_g") + row("fiber_g", True) + row("sugar_g", True)
        + row("protein_g")
        + "<div class=\"foot\">* Estimated. % Daily Value based on a 2,000-calorie diet.</div></div>"
    )


def _method_html(recipe: Recipe, kitchen: list[str] | None) -> str:
    method = cooking_method(recipe, kitchen)
    if method is None:
        missing = ", ".join(e for e in recipe.equipment if e not in (kitchen or []))
        return f"<p class=\"over\">Needs equipment you don't have: {escape(missing)}</p>"
    if not method["equipment"]:
        chips = "<span class=\"equip\">no cooking</span>"
    else:
        chips = "".join(f"<span class=\"equip\">{escape(e)}</span>" for e in method["equipment"])
    adapt = "".join(
        f"<div class=\"adapt\"><b>For your kitchen:</b> {escape(n)}</div>"
        for n in method["adaptations"]
    )
    return f"<div>{chips}</div>{adapt}"


def _cook_qty(quantity: float, base: int, makes: int) -> float:
    """Exact amount to cook for `makes` servings, to the nearest 1/4.

    Unlike the shopping list (which rounds up to whole packages), a recipe
    should say "1/2 lb spaghetti" when cooking for 2 from a 4-serving recipe.
    """
    exact = quantity * makes / (base or 1)
    return max(0.25, round(exact * 4) / 4)


def recipe_section(
    recipe: Recipe,
    household_size: int | None = None,
    kitchen: list[str] | None = None,
) -> str:
    from .planning.nutrition import per_serving

    makes = household_size or recipe.base_servings
    ings = "".join(
        "<li>{} {} {}</li>".format(
            _num(_cook_qty(i.quantity, recipe.base_servings, makes)),
            escape(i.unit),
            escape(i.name),
        )
        for i in recipe.ingredients
    )
    steps = "".join(f"<li>{escape(s)}</li>" for s in recipe.steps) or (
        "<li class=\"muted\">Steps not available for this recipe.</li>"
    )
    diets = f" · {escape(', '.join(recipe.diets))}" if recipe.diets else ""
    return (
        "<section class=\"recipe\"><div>"
        f"<h3>{escape(recipe.name)}</h3>"
        f"<div class=\"sub\">{escape(recipe.cuisine)}{diets} · makes {makes} servings</div>"
        f"<h4>Equipment</h4>{_method_html(recipe, kitchen)}"
        f"<h4>Ingredients</h4><ul>{ings}</ul>"
        f"<h4>Steps</h4><ol>{steps}</ol>"
        f"</div>{nutrition_label(per_serving(recipe), '1 serving (1/' + str(recipe.base_servings) + ' of the recipe as written)')}"
        "</section>"
    )


def _schedule_table(schedule: dict | None, meal_types: list[str]) -> str:
    """Sunday–Saturday grid of which meal to eat when, with planned calories."""
    if not schedule:
        return ""
    types = [t for t in ("breakfast", "lunch", "dinner") if t in meal_types] or ["dinner"]
    head = "".join(f"<th>{t.capitalize()}</th>" for t in types)
    rows = []
    for d in schedule["days"]:
        by_type = {m["meal_type"]: m for m in d["meals"]}
        cells = "".join(
            f"<td>{escape(m['name'])} <span class=\"muted\">({m['calories']:,.0f} cal)</span></td>"
            if (m := by_type.get(t)) and m.get("name")
            else "<td class=\"muted\">open — leftovers / out</td>"
            for t in types
        )
        when = _as_date(d["date"])
        rows.append(
            f"<tr><td><b>{escape(d['day'])}</b><br><span class=\"muted\">{when:%b} {when.day}</span></td>"
            f"{cells}<td>{d['planned_calories']:,.0f}</td></tr>"
        )
    extra = schedule.get("unscheduled") or []
    more = (
        "<p class=\"cap\">Not scheduled (more meals than slots): "
        + ", ".join(escape(m["name"]) for m in extra) + "</p>"
    ) if extra else ""
    return (
        "<h2>Week at a glance</h2><div class=\"tablewrap\"><table class=\"week\"><thead><tr><th>Day</th>"
        f"{head}<th>Planned calories*</th></tr></thead><tbody>{''.join(rows)}</tbody></table></div>"
        "<p class=\"cap\">* One serving of each planned meal; open slots and snacks not counted.</p>"
        + more
    )


def plan_report(plan: dict) -> str:
    """Recipe book for a generated plan: every meal's recipe + Nutrition Facts."""
    kitchen = plan.get("kitchen")
    household = plan.get("household_size")
    meals = [m for m in plan.get("meals", []) if m["id"] in RECIPES_BY_ID]

    rows = "".join(
        "<tr><td>{}</td><td>{}</td>{}</tr>".format(
            escape(m["name"]),
            escape(m["cuisine"]),
            "".join(
                f"<td>{_unit((m.get('nutrition') or {}).get(k, 0), k)}</td>"
                for k in ("calories", "protein_g", "carbs_g", "fat_g", "sodium_mg")
            ),
        )
        for m in meals
    )
    overview = (
        "<h2>Meals at a glance (per serving)</h2><div class=\"tablewrap\"><table><thead><tr>"
        "<th>Meal</th><th>Cuisine</th><th>Calories</th><th>Protein</th><th>Carbs</th>"
        "<th>Fat</th><th>Sodium</th></tr></thead>"
        f"<tbody>{rows}</tbody></table></div>"
    )
    tip = plan.get("stove_tip")
    tip_html = f"<div class=\"tip\">{escape(tip)}</div>" if tip else ""
    kitchen_txt = ", ".join(kitchen) if kitchen else "full kitchen"
    sections = "".join(
        recipe_section(RECIPES_BY_ID[m["id"]], household, kitchen) for m in meals
    )
    shopping = "".join(
        f"<tr><td>{escape(i['ingredient'])}</td><td>{escape(i['department'])}</td>"
        f"<td>{_num(i['quantity'])} {escape(i['unit'])}</td></tr>"
        for i in plan.get("shopping_list", [])
    )
    week_html = _schedule_table(plan.get("schedule"), plan.get("meal_types") or [])
    start = plan.get("week_start")
    title = f"Week of {_day(_as_date(start))}" if start else f"Week {plan.get('week', '')}"
    body = (
        f"<h1>Meal Plan — {escape(title)}</h1>"
        f"<p class=\"meta\">{household} people · {len(meals)} meals · "
        f"kitchen: {escape(kitchen_txt)}</p>"
        f"{tip_html}{week_html}{overview}<h2>Recipes</h2>{sections}"
        "<h2>Shopping list</h2><div class=\"tablewrap\"><table><thead><tr><th>Item</th>"
        f"<th>Department</th><th>Amount</th></tr></thead><tbody>{shopping}</tbody></table></div>"
    )
    return _page(f"Meal Plan {plan.get('week', '')}", body)


_TABLE_KEYS = ("calories", "protein_g", "carbs_g", "fat_g", "sat_fat_g", "fiber_g", "sugar_g", "sodium_mg")

# Daily guidelines (FDA Daily Values on a 2,000-calorie diet).
SODIUM_LIMIT = 2300
SAT_FAT_LIMIT = 20
FIBER_TARGET = 28
PROTEIN_TARGET = 50
# Acceptable Macronutrient Distribution Ranges (% of calories), Dietary Guidelines.
MACRO_RANGES = {"protein": (10, 35), "carbs": (45, 65), "fat": (20, 35)}
MEAL_TYPE_ORDER = ("breakfast", "lunch", "dinner", "snack")


def _as_date(v) -> date:
    return v if isinstance(v, date) else date.fromisoformat(str(v))


def _status(ok: bool, good: str, bad: str) -> str:
    # Status is always icon + words, never color alone.
    return (f'<span class="ok">✓ {escape(good)}</span>' if ok
            else f'<span class="over">⚠ {escape(bad)}</span>')


def _macro_kcal(t: dict) -> dict[str, float]:
    return {"protein": t["protein_g"] * 4, "carbs": t["carbs_g"] * 4, "fat": t["fat_g"] * 9}


def log_stats(days: list[dict], calorie_goal: float | None = None) -> dict:
    """All the math behind the report, separate from rendering (and tested)."""
    logged = [d for d in days if d["entries"]]
    n = len(logged)
    if not n:
        return {"days_logged": 0, "days_in_range": len(days)}
    totals = {k: sum(d["totals"][k] for d in logged) for k in NUTRIENTS}
    avg = {k: v / n for k, v in totals.items()}

    macro = _macro_kcal(totals)
    macro_sum = sum(macro.values()) or 1
    macro_pct = {k: 100 * v / macro_sum for k, v in macro.items()}

    by_day = sorted(logged, key=lambda d: d["totals"]["calories"])
    meal_cal: dict[str, float] = {}
    foods: dict[str, dict] = {}
    entries = 0
    for d in logged:
        for e in d["entries"]:
            entries += 1
            meal_cal[e["meal_type"]] = meal_cal.get(e["meal_type"], 0) + e["nutrition"]["calories"]
            f = foods.setdefault(e["name"], {"name": e["name"], "times": 0, "calories": 0.0,
                                             "sodium_mg": 0.0, "sat_fat_g": 0.0, "fiber_g": 0.0})
            f["times"] += 1
            for k in ("calories", "sodium_mg", "sat_fat_g", "fiber_g"):
                f[k] += e["nutrition"][k]
    all_cal = totals["calories"] or 1
    for f in foods.values():
        f["pct_calories"] = 100 * f["calories"] / all_cal

    def count(pred) -> int:
        return sum(1 for d in logged if pred(d["totals"]))

    return {
        "days_logged": n,
        "days_in_range": len(days),
        "entries": entries,
        "totals": totals,
        "avg": avg,
        "macro_pct": macro_pct,
        "macro_kcal_avg": {k: v / n for k, v in macro.items()},
        "highest": (by_day[-1]["date"], by_day[-1]["totals"]["calories"]),
        "lowest": (by_day[0]["date"], by_day[0]["totals"]["calories"]),
        "days_over_goal": count(lambda t: t["calories"] > calorie_goal) if calorie_goal else None,
        "days_over_sodium": count(lambda t: t["sodium_mg"] > SODIUM_LIMIT),
        "days_over_sat_fat": count(lambda t: t["sat_fat_g"] > SAT_FAT_LIMIT),
        "days_under_fiber": count(lambda t: t["fiber_g"] < FIBER_TARGET),
        "days_under_protein": count(lambda t: t["protein_g"] < PROTEIN_TARGET),
        "meal_avg_calories": {
            t: meal_cal[t] / n for t in MEAL_TYPE_ORDER if t in meal_cal
        },
        "foods": sorted(foods.values(), key=lambda f: -f["calories"]),
    }


def _top_sources(foods: list[dict], key: str, k: int = 3) -> str:
    top = sorted(foods, key=lambda f: -f[key])[:k]
    return ", ".join(escape(f["name"]) for f in top if f[key] > 0)


def log_report(
    days: list[dict],
    start: date,
    end: date,
    calorie_goal: float | None = None,
    name: str | None = None,
    kitchen: list[str] | None = None,
) -> str:
    """Doctor-ready food diary: summary math, charts, guideline comparison,
    most-eaten foods, the day-by-day log and the recipes eaten.

    `days` is the shape returned by the /log API: [{date, totals, entries}].
    """
    from . import charts

    days = [{**d, "date": _as_date(d["date"])} for d in days]
    logged = [d for d in days if d["entries"]]
    st = log_stats(days, calorie_goal)
    who = f" — {escape(name)}" if name else ""
    header = (
        f"<h1>Food &amp; Nutrition Log{who}</h1>"
        f"<p class=\"meta\">{_day(start)} – {_day(end)} · generated {_day(date.today())}</p>"
    )
    if not logged:
        return _page(
            f"Food Log {start.isoformat()} to {end.isoformat()}",
            header + "<p class=\"muted\">No meals logged in this range.</p>",
        )

    avg = st["avg"]
    n = st["days_logged"]

    # --- Summary tiles ---------------------------------------------------
    hi_d, hi_v = st["highest"]
    lo_d, lo_v = st["lowest"]
    cards = [
        ("Avg calories / day", f"{round(avg['calories']):,}",
         f"goal {round(calorie_goal):,}" if calorie_goal else ""),
        ("Days logged", f"{n} of {st['days_in_range']}", f"{st['entries']} meals & snacks"),
        ("Total calories", f"{round(st['totals']['calories']):,}", "all logged days"),
        ("Highest day", f"{round(hi_v):,}", _day(hi_d, weekday=True)),
        ("Lowest day", f"{round(lo_v):,}", _day(lo_d, weekday=True)),
        ("Avg protein / day", f"{round(avg['protein_g'])}g", ""),
        ("Avg sodium / day", f"{round(avg['sodium_mg']):,}mg", f"limit {SODIUM_LIMIT:,}mg"),
        ("Avg fiber / day", f"{round(avg['fiber_g'])}g", f"target {FIBER_TARGET}g"),
    ]
    if calorie_goal:
        cards.insert(2, ("Days over calorie goal", f"{st['days_over_goal']} of {n}", ""))
    summary = "<div class=\"summary\">" + "".join(
        f"<div><span class=\"muted\">{escape(k)}</span><b>{escape(v)}</b>"
        f"<small>{escape(sub)}</small></div>" for k, v, sub in cards
    ) + "</div>"

    # --- Highlights (facts only, for the conversation with the doctor) -------
    foods = st["foods"]
    hl = []
    if calorie_goal:
        diff = round(avg["calories"] - calorie_goal)
        hl.append(
            f"Calories averaged <b>{round(avg['calories']):,}/day</b>, "
            f"{abs(diff):,} {'above' if diff > 0 else 'below'} the {round(calorie_goal):,} goal; "
            f"over the goal on {st['days_over_goal']} of {n} days."
        )
    else:
        hl.append(f"Calories averaged <b>{round(avg['calories']):,}/day</b> over {n} logged days.")
    hl.append(
        f"Sodium averaged <b>{round(avg['sodium_mg']):,} mg/day</b> (limit {SODIUM_LIMIT:,}); "
        f"above the limit on {st['days_over_sodium']} of {n} days. "
        f"Biggest sources: {_top_sources(foods, 'sodium_mg')}."
    )
    hl.append(
        f"Saturated fat averaged <b>{avg['sat_fat_g']:.0f} g/day</b> (limit {SAT_FAT_LIMIT} g); "
        f"above on {st['days_over_sat_fat']} of {n} days. "
        f"Biggest sources: {_top_sources(foods, 'sat_fat_g')}."
    )
    hl.append(
        f"Fiber averaged <b>{avg['fiber_g']:.0f} g/day</b> (target {FIBER_TARGET} g); "
        f"below target on {st['days_under_fiber']} of {n} days."
    )
    mp = st["macro_pct"]
    hl.append(
        f"Calories came {mp['protein']:.0f}% from protein, {mp['carbs']:.0f}% from carbs "
        f"and {mp['fat']:.0f}% from fat."
    )
    highlights = "<ul class=\"highlights\">" + "".join(f"<li>{h}</li>" for h in hl) + "</ul>"

    # --- Charts --------------------------------------------------------------
    cal_chart = (
        charts.legend([(charts.SERIES[0], "Protein"), (charts.SERIES[1], "Carbs"),
                       (charts.SERIES[2], "Fat")])
        + charts.daily_calories(days, calorie_goal)
        + "<p class=\"cap\">Each column is one day's calories, split by where they came "
        "from. “–” = nothing logged.</p>"
    )
    small = [
        ("Sodium (mg)", "sodium_mg", "mg", SODIUM_LIMIT, f"Limit {SODIUM_LIMIT:,}"),
        ("Saturated fat (g)", "sat_fat_g", "g", SAT_FAT_LIMIT, f"Limit {SAT_FAT_LIMIT}g"),
        ("Fiber (g)", "fiber_g", "g", FIBER_TARGET, f"Target {FIBER_TARGET}g"),
        ("Protein (g)", "protein_g", "g", PROTEIN_TARGET, f"DV {PROTEIN_TARGET}g"),
    ]
    multiples = "<div class=\"multiples\">" + "".join(
        f"<figure><figcaption>{escape(title)}</figcaption>"
        f"{charts.daily_metric(days, key, unit, ref, ref_label)}</figure>"
        for title, key, unit, ref, ref_label in small
    ) + "</div>"

    # --- Guideline table -----------------------------------------------------
    def row(label, value, guide, outside, status):
        return (f"<tr><td>{label}</td><td>{value}</td><td>{guide}</td>"
                f"<td>{outside}</td><td>{status}</td></tr>")

    g_rows = []
    if calorie_goal:
        g_rows.append(row("Calories", f"{round(avg['calories']):,}", f"≤ {round(calorie_goal):,} (your goal)",
                          f"{st['days_over_goal']} of {n} days over",
                          _status(avg["calories"] <= calorie_goal, "At or under goal", "Above goal")))
    g_rows += [
        row("Sodium", f"{round(avg['sodium_mg']):,}mg", f"≤ {SODIUM_LIMIT:,}mg",
            f"{st['days_over_sodium']} of {n} days over",
            _status(avg["sodium_mg"] <= SODIUM_LIMIT, "Within limit", "Above limit")),
        row("Saturated fat", f"{avg['sat_fat_g']:.0f}g", f"≤ {SAT_FAT_LIMIT}g",
            f"{st['days_over_sat_fat']} of {n} days over",
            _status(avg["sat_fat_g"] <= SAT_FAT_LIMIT, "Within limit", "Above limit")),
        row("Fiber", f"{avg['fiber_g']:.0f}g", f"≥ {FIBER_TARGET}g",
            f"{st['days_under_fiber']} of {n} days under",
            _status(avg["fiber_g"] >= FIBER_TARGET, "Meets target", "Below target")),
        row("Protein", f"{avg['protein_g']:.0f}g", f"≥ {PROTEIN_TARGET}g (Daily Value)",
            f"{st['days_under_protein']} of {n} days under",
            _status(avg["protein_g"] >= PROTEIN_TARGET, "Meets Daily Value", "Below Daily Value")),
        row("Total carbs", f"{avg['carbs_g']:.0f}g", "275g (Daily Value, reference)", "—", "—"),
        row("Total fat", f"{avg['fat_g']:.0f}g", "78g (Daily Value, reference)", "—", "—"),
        row("Total sugars", f"{avg['sugar_g']:.0f}g", "no Daily Value (includes natural sugars)", "—", "—"),
    ]
    guidelines = (
        "<div class=\"tablewrap\"><table class=\"left\"><thead><tr><th>Nutrient</th><th>Avg / day</th>"
        "<th>Guideline</th><th>Days outside</th><th>Status</th></tr></thead>"
        f"<tbody>{''.join(g_rows)}</tbody></table></div>"
    )

    m_rows = "".join(
        f"<tr><td>{label}</td><td>{avg[key]:.0f}g</td><td>{round(st['macro_kcal_avg'][m]):,}</td>"
        f"<td>{mp[m]:.0f}%</td><td>{lo}–{hi}%</td>"
        f"<td>{_status(lo <= mp[m] <= hi, 'In range', 'Below range' if mp[m] < lo else 'Above range')}</td></tr>"
        for m, label, key in (("protein", "Protein", "protein_g"), ("carbs", "Carbs", "carbs_g"),
                              ("fat", "Fat", "fat_g"))
        for lo, hi in [MACRO_RANGES[m]]
    )
    macros = (
        "<div class=\"tablewrap\"><table class=\"left\"><thead><tr><th>Source</th><th>Avg grams / day</th>"
        "<th>Avg calories / day</th><th>% of calories</th><th>Recommended</th><th>Status</th></tr></thead>"
        f"<tbody>{m_rows}</tbody></table></div>"
    )

    # --- Meals & foods -------------------------------------------------------
    meal_avg = st["meal_avg_calories"]
    meal_total = sum(meal_avg.values()) or 1
    meal_chart = charts.horizontal_bars([(t.capitalize(), v) for t, v in meal_avg.items()], " cal")
    meal_table = "".join(
        f"<tr><td>{t.capitalize()}</td><td>{round(v):,}</td><td>{100 * v / meal_total:.0f}%</td></tr>"
        for t, v in meal_avg.items()
    )
    meals = (
        f"{meal_chart}<p class=\"cap\">Average calories per logged day from each meal.</p>"
        "<div class=\"tablewrap\"><table class=\"left\"><thead><tr><th>Meal</th><th>Avg calories / day</th>"
        f"<th>% of daily calories</th></tr></thead><tbody>{meal_table}</tbody></table></div>"
    )
    f_rows = "".join(
        f"<tr><td>{escape(f['name'])}</td><td>{f['times']}</td><td>{round(f['calories']):,}</td>"
        f"<td>{f['pct_calories']:.0f}%</td><td>{round(f['calories'] / f['times']):,}</td>"
        f"<td>{round(f['sodium_mg'] / f['times']):,}mg</td><td>{f['sat_fat_g'] / f['times']:.0f}g</td></tr>"
        for f in foods[:15]
    )
    top_foods = (
        "<div class=\"tablewrap\"><table class=\"left\"><thead><tr><th>Food</th><th>Times eaten</th>"
        "<th>Total calories</th><th>% of all calories</th><th>Calories each</th><th>Sodium each</th>"
        f"<th>Sat. fat each</th></tr></thead><tbody>{f_rows}</tbody></table></div>"
        + (f"<p class=\"cap\">Top 15 of {len(foods)} foods, by total calories.</p>" if len(foods) > 15 else "")
    )

    # --- Day-by-day log ------------------------------------------------------
    head = "".join(f"<th>{_LABELS[k]}</th>" for k in _TABLE_KEYS)
    day_html = []
    for d in logged:
        rows = []
        for e in d["entries"]:
            note = f"<div class=\"note\">{escape(e['notes'])}</div>" if e.get("notes") else ""
            servings = f" × {_num(e['servings'])}" if e["servings"] != 1 else ""
            rows.append(
                f"<tr><td>{escape(e['meal_type'])}</td><td>{escape(e['name'])}{servings}{note}</td>"
                + "".join(f"<td>{_unit(e['nutrition'][k], k)}</td>" for k in _TABLE_KEYS)
                + "</tr>"
            )
        totals = d["totals"]
        rows.append(
            "<tr class=\"total\"><td>Total</td><td></td>"
            + "".join(f"<td>{_unit(round(totals[k]), k)}</td>" for k in _TABLE_KEYS)
            + "</tr>"
        )
        goal = ""
        if calorie_goal:
            diff = round(totals["calories"] - calorie_goal)
            goal = " · " + _status(diff <= 0, f"{abs(diff):,} cal under goal", f"{diff:,} cal over goal")
        day_html.append(
            f"<div class=\"day\"><h3>{_day(d['date'], weekday=True)}{goal}</h3>"
            f"<div class=\"tablewrap\"><table><thead><tr><th>Meal</th><th>Food</th>{head}</tr></thead>"
            f"<tbody>{''.join(rows)}</tbody></table></div></div>"
        )

    eaten_ids = []
    for d in logged:
        for e in d["entries"]:
            rid = e.get("recipe_id")
            if rid in RECIPES_BY_ID and rid not in eaten_ids:
                eaten_ids.append(rid)
    recipes = "".join(recipe_section(RECIPES_BY_ID[r], None, kitchen) for r in eaten_ids)

    body = (
        header
        + f"<h2>Summary</h2>{summary}<h3 class=\"sub3\">Highlights</h3>{highlights}"
        + f"<h2>Calories each day</h2>{cal_chart}"
        + f"<h2>Compared with daily guidelines</h2>{guidelines}"
        + f"<h2>Key nutrients each day</h2>{multiples}"
        + f"<h2>Where calories come from</h2>{macros}"
        + f"<h2>Calories by meal</h2>{meals}"
        + f"<h2>Most-eaten foods</h2>{top_foods}"
        + f"<h2>Daily log</h2>{''.join(day_html)}"
        + (f"<h2>Recipes eaten</h2>{recipes}" if recipes else "")
    )
    return _page(f"Food Log {start.isoformat()} to {end.isoformat()}", body)


def log_csv(days: list[dict]) -> str:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["date", "meal_type", "food", "servings", *NUTRIENTS, "notes"])
    for d in days:
        for e in d["entries"]:
            w.writerow([
                str(d["date"]), e["meal_type"], e["name"], e["servings"],
                *(e["nutrition"][k] for k in NUTRIENTS), e.get("notes") or "",
            ])
    return buf.getvalue()
