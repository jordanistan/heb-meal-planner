"""Build a weekly plan: choose meals, consolidate ingredients, map to H-E-B.

The plan covers a 7-day, Sunday-to-Saturday week for the chosen meal types
(lunch + dinner by default, breakfast optional) — we don't ask for a raw meal
count — and schedules each meal onto a day and slot. An optional budget caps
how many meals are included. Costs are rough estimates (see
pricing.py); the "buy" step is always a heb.com deep link.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone

from . import coupons, mapping, nutrition, pricing
from .recipes import (
    DEFAULT_PANTRY,
    RECIPES_BY_ID,
    Recipe,
    cooking_method,
    filter_recipes,
    stove_tip,
)

WEEK_DAYS = 7
MAX_MEALS = 21  # cap so 3 meal types * 7 days stays sane
MEAL_ORDER = ("breakfast", "lunch", "dinner")
DAY_NAMES = ("Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")


@dataclass
class PlanRequest:
    household_size: int = 2
    meal_types: list[str] = field(default_factory=lambda: ["lunch", "dinner"])
    cuisines: list[str] | None = None
    # Diet lanes and/or "only these" proteins (a single string also works).
    diet: str | list[str] | None = None
    anchor_meal_ids: list[str] | None = None
    pantry_exclude: list[str] | None = None
    budget: float | None = None
    fulfillment: str = "pickup"
    # Equipment the household has (None = assume a full kitchen) + stove type.
    kitchen: list[str] | None = None
    stove: str | None = None
    # Any date in the week to plan; snapped to that week's Sunday.
    # None = this Sunday if today is Sunday, else the coming Sunday.
    week_start: date | None = None


def scale(quantity: float, base_servings: int, household_size: int) -> float:
    factor = household_size / base_servings if base_servings else 1
    scaled = quantity * factor
    return float(math.ceil(scaled)) if quantity == int(quantity) else round(scaled, 1)


def _recipe_cost(recipe: Recipe) -> float:
    """Rough standalone cost of a recipe (sum of its ingredient line prices)."""
    return round(
        sum(
            pricing.estimate(i.name)
            for i in recipe.ingredients
            if not i.pantry and i.name.lower() not in DEFAULT_PANTRY
        ),
        2,
    )


def _meal_types(req: PlanRequest) -> list[str]:
    asked = {t for t in (req.meal_types or []) if t}
    return [t for t in MEAL_ORDER if t in asked] or ["dinner"]


def _target_count(req: PlanRequest) -> int:
    return min(MAX_MEALS, WEEK_DAYS * len(_meal_types(req)))


def week_sunday(d: date | None = None, today: date | None = None) -> date:
    """The Sunday that starts the plan's week."""
    if d is not None:
        return d - timedelta(days=(d.weekday() + 1) % 7)  # Sunday on/before
    today = today or date.today()
    return today + timedelta(days=(6 - today.weekday()) % 7)  # today or next Sunday


def _spread(n_items: int, n_slots: int) -> list[int]:
    """Slot indices that spread n items evenly over n slots (n <= slots)."""
    if n_items <= 0:
        return []
    return [i * n_slots // n_items for i in range(n_items)]


def build_schedule(meals: list[Recipe], meal_types: list[str], start: date) -> dict:
    """Assign each meal to a day (Sun–Sat) and slot.

    Breakfast recipes fill breakfast slots; everything else fills lunch/dinner.
    Each meal is placed once (the shopping list buys one batch of each), spread
    evenly so open slots fall between cooked meals (leftovers / eating out).
    Meals beyond the available slots are returned as `unscheduled`.
    """
    has_breakfast = "breakfast" in meal_types
    main_types = [t for t in meal_types if t != "breakfast"]
    b_queue = [r for r in meals if has_breakfast and r.cuisine == "breakfast"]
    m_queue = [r for r in meals if r not in b_queue]
    if not main_types:  # breakfast-only week: everything goes to breakfast
        b_queue, m_queue = b_queue + m_queue, []

    b_slots = [(d, "breakfast") for d in range(WEEK_DAYS)] if has_breakfast else []
    m_slots = [(d, t) for d in range(WEEK_DAYS) for t in main_types]
    placed: dict[tuple[int, str], Recipe] = {}
    unscheduled: list[Recipe] = []
    for queue, slots in ((b_queue, b_slots), (m_queue, m_slots)):
        fit, extra = queue[: len(slots)], queue[len(slots):]
        unscheduled.extend(extra)
        for recipe, idx in zip(fit, _spread(len(fit), len(slots))):
            placed[slots[idx]] = recipe

    days = []
    for d in range(WEEK_DAYS):
        entries = []
        for t in meal_types:
            r = placed.get((d, t))
            entries.append({
                "meal_type": t,
                "id": r.id if r else None,
                "name": r.name if r else None,
                "calories": nutrition.per_serving(r)["calories"] if r else None,
            })
        days.append({
            "date": (start + timedelta(days=d)).isoformat(),
            "day": DAY_NAMES[d],
            "meals": entries,
            "planned_calories": round(sum(e["calories"] or 0 for e in entries)),
        })
    return {
        "days": days,
        "unscheduled": [{"id": r.id, "name": r.name} for r in unscheduled],
    }


def _interleave_cuisines(pool: list[Recipe]) -> list[Recipe]:
    """Round-robin across cuisines so a multi-cuisine week mixes them
    (deterministic: library order within each cuisine)."""
    by_cuisine: dict[str, list[Recipe]] = {}
    for r in pool:
        by_cuisine.setdefault(r.cuisine, []).append(r)
    queues = list(by_cuisine.values())
    out: list[Recipe] = []
    for i in range(max((len(q) for q in queues), default=0)):
        out.extend(q[i] for q in queues if i < len(q))
    return out


def _choose_meals(req: PlanRequest) -> list[Recipe]:
    """The plan is the meals the user selected.

    - If any anchor meals are selected, the plan is exactly those (distinct,
      no auto-fill, no repeats) — we never add meals the user didn't pick.
    - If NO anchors are selected, suggest a week: distinct meals from the
      chosen cuisines/diet that the household's kitchen can make, up to the
      weekly target and within any budget.
    """
    # Selected anchors define the plan.
    chosen: list[Recipe] = []
    seen: set[str] = set()
    for mid in req.anchor_meal_ids or []:
        recipe = RECIPES_BY_ID.get(mid)
        if recipe and recipe.id not in seen:
            chosen.append(recipe)
            seen.add(recipe.id)
    if chosen:
        return chosen

    # No anchors: suggest a distinct week. Breakfast slots draw from breakfast
    # recipes (whatever cuisines were picked); lunch/dinner from the chosen
    # cuisines. Picks go in day order so a tight budget still covers whole days.
    types = _meal_types(req)
    main_types = [t for t in types if t != "breakfast"]
    pool = filter_recipes(req.cuisines, req.diet, req.kitchen)
    mains = _interleave_cuisines([r for r in pool if r.cuisine != "breakfast"])
    breakfasts = (
        [r for r in filter_recipes(["breakfast"], req.diet, req.kitchen)]
        if "breakfast" in types else []
    )
    if not mains and main_types:  # e.g. only "breakfast" cuisine picked
        mains = [r for r in pool if r not in breakfasts]

    order: list[Recipe] = []
    b_iter, m_iter = iter(breakfasts), iter(mains)
    for _ in range(WEEK_DAYS):
        if "breakfast" in types:
            order.extend(r for r in [next(b_iter, None)] if r)
        for _t in main_types:
            order.extend(r for r in [next(m_iter, None)] if r)

    target = _target_count(req)
    budget = req.budget if req.budget and req.budget > 0 else None
    running = 0.0
    for recipe in order[:target]:
        cost = _recipe_cost(recipe)
        if budget is not None and chosen and running + cost > budget:
            break  # next meal would blow the budget
        chosen.append(recipe)
        running += cost
    return chosen


def generate_plan(req: PlanRequest) -> dict:
    meals = _choose_meals(req)
    pantry = DEFAULT_PANTRY | {p.lower() for p in (req.pantry_exclude or [])}

    # Consolidate: (ingredient, unit) -> summed quantity + metadata.
    agg: dict[tuple[str, str], dict] = {}
    for recipe in meals:
        for ing in recipe.ingredients:
            if ing.pantry or ing.name.lower() in pantry:
                continue
            qty = scale(ing.quantity, recipe.base_servings, req.household_size)
            key = (ing.name, ing.unit)
            if key in agg:
                agg[key]["quantity"] += qty
            else:
                agg[key] = {
                    "ingredient": ing.name,
                    "quantity": qty,
                    "unit": ing.unit,
                    "department": ing.department,
                    "cuisine": recipe.cuisine,
                }

    shopping_list = []
    matched_coupons: dict[str, dict] = {}
    estimated_total = 0.0
    for item in agg.values():
        query = mapping.query_for(item["ingredient"], item["cuisine"])
        cost = pricing.estimate(item["ingredient"])
        estimated_total += cost
        coupon = coupons.match_for(item["ingredient"], query)
        if coupon:
            matched_coupons[coupon["match"]] = coupon
        shopping_list.append(
            {
                "ingredient": item["ingredient"],
                "quantity": round(item["quantity"], 1),
                "unit": item["unit"],
                "department": item["department"],
                "heb_query": query,
                "brand": mapping.brand_of(query),
                "deep_link": mapping.deep_link(query),
                "est_cost": round(cost, 2),
                "coupon": coupon["deal"] if coupon else None,
            }
        )
    shopping_list.sort(key=lambda x: (x["department"], x["ingredient"]))

    # Aggregate meals with counts (repeats show as "x2").
    meal_counts: dict[str, dict] = {}
    for r in meals:
        if r.id in meal_counts:
            meal_counts[r.id]["count"] += 1
        else:
            method = cooking_method(r, req.kitchen)
            meal_counts[r.id] = {
                "id": r.id,
                "name": r.name,
                "cuisine": r.cuisine,
                "count": 1,
                "nutrition": nutrition.per_serving(r),
                "can_make": method is not None,
                "method": method,
            }

    coupon_list = list(matched_coupons.values())
    savings = round(sum(c["savings"] for c in coupon_list), 2)
    estimated_total = round(estimated_total, 2)
    budget = req.budget if req.budget and req.budget > 0 else None

    now = datetime.now(timezone.utc)
    start = week_sunday(req.week_start)
    types = _meal_types(req)
    return {
        "week": start.isoformat(),
        "week_start": start.isoformat(),
        "generated_at": now.isoformat(timespec="seconds"),
        "household_size": req.household_size,
        "meal_types": types,
        "schedule": build_schedule(meals, types, start),
        "fulfillment": "delivery" if req.fulfillment == "delivery" else "pickup",
        "kitchen": req.kitchen,
        "stove": req.stove,
        "stove_tip": stove_tip(req.stove),
        "meals": list(meal_counts.values()),
        "shopping_list": shopping_list,
        "estimated_total": estimated_total,
        "budget": budget,
        "under_budget": (estimated_total <= budget) if budget is not None else None,
        "coupons": coupon_list,
        "estimated_savings": savings,
    }
