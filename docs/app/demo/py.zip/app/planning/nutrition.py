"""Approximate nutrition facts for recipes.

Values are per ingredient *unit as used in the recipe library* (per lb, per
each, per cup dry, per can, ...) and are rounded averages of USDA FoodData
Central entries for a typical H-E-B product. They are ESTIMATES for meal
tracking — not lab values — and the reports say so.

For condiments bought by the bottle/jar but only partly used (soy sauce, BBQ
sauce, curry paste, ...) the value reflects the amount a recipe typically
uses, noted in the comment. Buttermilk used as a marinade counts only the
portion that clings to the food. Cooking spray, salt and pepper are ignored.
"""
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .recipes import Recipe

NUTRIENTS = (
    "calories", "protein_g", "carbs_g", "fat_g",
    "sat_fat_g", "fiber_g", "sugar_g", "sodium_mg",
)

# FDA daily values (2,000-calorie diet) for % Daily Value on labels.
DAILY_VALUES = {
    "fat_g": 78, "sat_fat_g": 20, "sodium_mg": 2300,
    "carbs_g": 275, "fiber_g": 28, "protein_g": 50,
}

# name -> (unit, (kcal, protein, carbs, fat, sat fat, fiber, sugar, sodium mg))
FACTS: dict[str, tuple[str, tuple[float, ...]]] = {
    # Beef / pork / poultry (raw weight)
    "skirt steak": ("lb", (930, 95, 0, 59, 23, 0, 0, 340)),
    "flank steak": ("lb", (700, 95, 0, 34, 14, 0, 0, 250)),
    "beef chuck": ("lb", (980, 80, 0, 72, 28, 0, 0, 300)),
    "brisket": ("lb", (1100, 80, 0, 86, 33, 0, 0, 300)),
    "ground beef": ("lb", (1150, 78, 0, 91, 35, 0, 0, 300)),
    "chicken breast": ("lb", (545, 102, 0, 12, 3, 0, 0, 205)),
    "chicken thighs": ("lb", (550, 89, 0, 19, 5, 0, 0, 430)),
    "ground turkey": ("lb", (680, 85, 0, 37, 10, 0, 0, 320)),
    "pork shoulder": ("lb", (1000, 80, 0, 73, 26, 0, 0, 300)),
    "pork chops": ("lb", (650, 95, 0, 28, 9, 0, 0, 230)),
    "pork tenderloin": ("lb", (545, 95, 0, 16, 5, 0, 0, 240)),
    "ground pork": ("lb", (1190, 77, 0, 96, 36, 0, 0, 255)),
    "italian sausage": ("lb", (1300, 64, 4, 112, 40, 0, 0, 3200)),
    "andouille": ("lb", (1100, 64, 8, 88, 32, 0, 0, 3600)),
    "smoked sausage": ("lb", (1300, 55, 10, 115, 40, 0, 4, 3800)),
    "breakfast sausage": ("lb", (1500, 60, 2, 136, 46, 0, 2, 3000)),
    "chorizo": ("lb", (2000, 100, 8, 170, 62, 0, 0, 5000)),
    "bacon": ("oz", (130, 10, 0.4, 10, 3.5, 0, 0, 500)),
    # Seafood
    "salmon": ("lb", (940, 92, 0, 61, 14, 0, 0, 270)),
    "shrimp": ("lb", (385, 91, 0, 2.5, 0.5, 0, 0, 540)),
    "cod": ("lb", (370, 81, 0, 3, 0.6, 0, 0, 240)),
    "tilapia": ("lb", (435, 91, 0, 8, 2.7, 0, 0, 240)),
    "catfish": ("lb", (430, 75, 0, 13, 3, 0, 0, 200)),
    "crawfish tails": ("lb", (350, 72, 0, 5, 1, 0, 0, 400)),
    # Eggs / dairy / plant protein
    "eggs": ("each", (72, 6.3, 0.4, 4.8, 1.6, 0, 0.2, 71)),
    "tofu": ("block", (400, 44, 8, 22, 3, 4, 1, 40)),
    "paneer": ("oz", (90, 6, 1, 7, 4.5, 0, 1, 10)),
    "feta": ("oz", (75, 4, 1.2, 6, 4.2, 0, 1.2, 320)),
    "cheddar": ("oz", (115, 7, 0.4, 9.5, 5.4, 0, 0.1, 180)),
    "mozzarella": ("oz", (85, 7, 1, 6, 3.5, 0, 0, 175)),
    "parmesan": ("oz", (110, 10, 1, 7, 4.5, 0, 0, 390)),
    "ricotta": ("oz", (49, 3.2, 0.9, 3.7, 2.3, 0, 0.1, 24)),
    "queso fresco": ("oz", (80, 5, 1, 6, 3.5, 0, 0, 200)),
    "oaxaca cheese": ("oz", (90, 7, 1, 7, 4, 0, 0, 150)),
    "sour cream": ("oz", (55, 0.7, 1.3, 5.5, 3.3, 0, 1, 10)),
    "buttermilk": ("qt", (200, 16, 24, 4.5, 2.5, 0, 24, 500)),  # ~2 cups absorbed
    "greek yogurt": ("cup", (220, 20, 9, 11, 7, 0, 9, 85)),
    "nonfat greek yogurt": ("cup", (130, 23, 9, 0.7, 0.2, 0, 9, 85)),
    "milk": ("cup", (122, 8, 12, 4.8, 3, 0, 12, 115)),
    "almond milk": ("cup", (40, 1, 2, 3, 0, 1, 0, 170)),
    "heavy cream": ("cup", (800, 6.6, 6.6, 86, 55, 0, 6.6, 64)),
    "butter": ("tbsp", (100, 0.1, 0, 11.5, 7.3, 0, 0, 90)),
    "hummus": ("container", (700, 20, 40, 52, 7, 16, 0, 1400)),  # 10 oz
    # Grains / bread / pasta (dry)
    "rice": ("cup", (675, 13, 148, 1.2, 0.3, 2.4, 0, 9)),
    "brown rice": ("cup", (685, 14.5, 143, 5.4, 1, 6.5, 1.6, 7)),
    "arborio rice": ("cup", (700, 13, 158, 1, 0.2, 3, 0, 0)),
    "quinoa": ("cup", (625, 24, 109, 10, 1.2, 12, 0, 9)),
    "farro": ("cup", (680, 26, 136, 4, 0.7, 20, 1.6, 10)),
    "bulgur": ("cup", (480, 17, 106, 1.9, 0.3, 25.6, 0.6, 24)),
    "couscous": ("cup", (650, 22, 134, 1.1, 0.2, 8.7, 0, 17)),
    "orzo": ("cup", (650, 23, 132, 3, 0.5, 7, 5, 0)),
    "grits": ("cup", (580, 14, 124, 2, 0.3, 6, 0, 2)),
    "oats": ("cup", (300, 10.7, 54, 5, 1, 8, 1, 5)),
    "granola": ("cup", (480, 11, 64, 20, 4, 7, 24, 40)),
    "flour": ("cup", (455, 13, 95, 1.2, 0.2, 3.4, 0.3, 3)),
    "cornmeal": ("cup", (440, 10, 94, 4, 0.6, 9, 0.8, 40)),
    "breadcrumbs": ("cup", (430, 14, 78, 6, 1.3, 5, 7, 790)),
    "spaghetti": ("lb", (1600, 56, 336, 8, 1.6, 16, 12, 0)),
    "pasta": ("lb", (1600, 56, 336, 8, 1.6, 16, 12, 0)),
    "elbow macaroni": ("lb", (1600, 56, 336, 8, 1.6, 16, 12, 0)),
    "lasagna noodles": ("box", (1600, 56, 336, 8, 1.6, 16, 12, 0)),  # 1 lb
    "egg noodles": ("oz", (108, 4, 20, 1.2, 0.3, 1, 0.7, 6)),
    "fideo": ("oz", (100, 3.5, 21, 0.5, 0.1, 1, 0.75, 0)),
    "rice noodles": ("oz", (102, 0.9, 23, 0.2, 0, 0.5, 0, 50)),
    "lo mein noodles": ("oz", (105, 3.7, 21, 0.5, 0.1, 1, 0.5, 5)),
    "corn tortillas": ("each", (52, 1.4, 10.7, 0.7, 0.1, 1.5, 0.2, 11)),
    "flour tortillas": ("each", (145, 3.8, 24, 3.6, 1.4, 1.4, 1, 330)),
    "pita": ("each", (165, 5.5, 33, 0.7, 0.1, 1.3, 0.8, 320)),
    "burger buns": ("each", (120, 4, 22, 2, 0.5, 1, 3, 210)),
    "hoagie rolls": ("each", (280, 9, 52, 3.5, 0.8, 2, 5, 500)),
    "english muffins": ("each", (130, 5, 26, 1, 0.2, 2, 2, 230)),
    "bread": ("slice", (80, 4, 14, 1, 0.2, 2, 2, 140)),
    "pizza dough": ("each", (1100, 32, 210, 14, 2, 8, 6, 2200)),  # 1 lb
    "pie crust": ("each", (880, 8, 88, 56, 22, 3, 6, 900)),
    # Beans / canned (15 oz cans unless noted)
    "black beans": ("can", (340, 21, 60, 1.5, 0.3, 21, 1, 1000)),
    "pinto beans": ("can", (360, 20, 58, 4, 1, 19, 2, 1400)),
    "refried beans": ("can", (390, 21, 63, 4, 1, 21, 2, 1900)),
    "kidney beans": ("can", (330, 22, 58, 1, 0.2, 17, 3, 650)),
    "cannellini beans": ("can", (320, 22, 56, 1, 0.3, 16, 2, 700)),
    "black-eyed peas": ("can", (300, 18, 54, 1.5, 0.4, 14, 1, 700)),
    "chickpeas": ("can", (350, 18, 57, 6, 0.6, 16, 10, 650)),
    "lentils": ("cup", (680, 50, 115, 2, 0.3, 20, 4, 12)),  # dry
    "hominy": ("can", (200, 4, 40, 2.4, 0.3, 7, 0, 900)),
    "canned tomatoes": ("can", (80, 4, 17, 0.5, 0, 4.4, 10, 650)),
    "tomato paste": ("can", (140, 7, 32, 0.8, 0.2, 7, 21, 100)),  # 6 oz
    "enchilada sauce": ("can", (100, 2, 14, 4, 0, 2, 4, 2000)),  # 10 oz
    "chipotle peppers": ("can", (60, 1, 10, 2, 0, 4, 4, 900)),  # ~half a can used
    "coconut milk": ("can", (670, 7, 10, 72, 64, 0, 0, 45)),
    "chicken broth": ("carton", (40, 6, 4, 1, 0, 0, 2, 2400)),  # 32 oz
    "beef broth": ("carton", (40, 6, 2, 0.5, 0, 0, 1, 2600)),
    "vegetable broth": ("carton", (50, 2, 10, 0, 0, 2, 4, 2200)),
    # Sauces / condiments (amount typically used)
    "marinara": ("jar", (400, 12, 60, 12, 1.6, 12, 36, 2500)),  # 24 oz
    "pesto": ("jar", (960, 18, 24, 90, 15, 6, 6, 2400)),
    "salsa verde": ("jar", (160, 4, 32, 0, 0, 8, 16, 3200)),
    "soy sauce": ("bottle", (40, 6, 4, 0, 0, 0.5, 1, 3600)),  # ~1/4 cup used
    "sesame oil": ("bottle", (240, 0, 0, 27, 3.9, 0, 0, 0)),  # ~2 tbsp used
    "gochujang": ("jar", (200, 4, 44, 2, 0, 2, 24, 2400)),  # ~1/4 cup used
    "curry paste": ("jar", (60, 2, 10, 2, 0, 2, 4, 2400)),  # ~1/4 cup used
    "bbq sauce": ("bottle", (380, 2, 92, 1.5, 0, 1.5, 76, 2400)),  # ~1 cup used
    "hoisin sauce": ("bottle", (140, 2, 28, 2, 0.4, 1, 18, 1600)),  # ~1/4 cup used
    "fish sauce": ("bottle", (12, 2, 1, 0, 0, 0, 1, 2800)),  # ~2 tbsp used
    "caesar dressing": ("bottle", (600, 2, 4, 64, 10, 0, 2, 1200)),  # ~1/2 cup used
    "tahini": ("cup", (1430, 41, 51, 129, 18, 22, 1, 280)),
    "peanut butter": ("tbsp", (95, 4, 3.5, 8, 1.6, 1, 1.5, 70)),
    "kalamata olives": ("cup", (240, 1.6, 6, 24, 3, 3, 0, 1800)),
    "capers": ("tbsp", (2, 0.2, 0.4, 0.1, 0, 0.3, 0, 200)),
    "honey": ("tbsp", (64, 0, 17, 0, 0, 0, 17, 1)),
    "maple syrup": ("tbsp", (52, 0, 13.4, 0, 0, 0, 12, 2)),
    "vegetable oil": ("tbsp", (120, 0, 0, 14, 1, 0, 0, 0)),
    "peanuts": ("oz", (165, 7, 6, 14, 2, 2.4, 1.2, 90)),
    "walnuts": ("oz", (185, 4.3, 3.9, 18.5, 1.7, 1.9, 0.7, 1)),
    # Spices
    "chili powder": ("tbsp", (25, 1, 4, 1.3, 0.2, 2.7, 0.6, 80)),
    "cumin": ("tbsp", (22, 1, 2.6, 1.3, 0.1, 0.6, 0, 10)),
    "garam masala": ("tbsp", (20, 0.9, 3.5, 0.9, 0.1, 2, 0.2, 5)),
    "curry powder": ("tbsp", (20, 0.9, 3.5, 0.9, 0.1, 2, 0.2, 5)),
    "cajun seasoning": ("tbsp", (15, 0.5, 3, 0.3, 0, 1, 0, 2000)),
    "taco seasoning": ("packet", (90, 0, 18, 0, 0, 0, 6, 1800)),
    # Produce
    "onion": ("each", (44, 1.2, 10, 0.1, 0, 1.9, 4.7, 4)),
    "garlic": ("clove", (4.5, 0.2, 1, 0, 0, 0.1, 0, 0.5)),
    "ginger": ("each", (22, 0.5, 5, 0.2, 0, 0.6, 0.5, 4)),  # ~1 oz knob
    "poblano": ("each", (20, 0.9, 4.5, 0.2, 0, 1.6, 2.4, 3)),
    "serrano": ("each", (2, 0.1, 0.4, 0, 0, 0.2, 0.3, 1)),
    "jalapeno": ("each", (4, 0.1, 0.9, 0.1, 0, 0.4, 0.6, 0)),
    "bell pepper": ("each", (30, 1, 7, 0.3, 0, 2.5, 5, 5)),
    "tomatillo": ("each", (11, 0.3, 2, 0.3, 0, 0.6, 1.3, 0)),
    "tomato": ("each", (11, 0.5, 2.4, 0.1, 0, 0.7, 1.6, 3)),
    "cherry tomatoes": ("pint", (54, 2.7, 12, 0.6, 0.1, 3.6, 8, 15)),
    "lime": ("each", (20, 0.5, 7, 0.1, 0, 1.9, 1.1, 1)),
    "lemon": ("each", (17, 0.6, 5.4, 0.2, 0, 1.6, 1.5, 1)),
    "avocado": ("each", (240, 3, 12.8, 22, 3.1, 10, 1, 11)),
    "cilantro": ("bunch", (7, 0.6, 1, 0.1, 0, 0.8, 0.2, 13)),
    "parsley": ("bunch", (22, 1.8, 3.8, 0.5, 0.1, 2, 0.5, 34)),
    "basil": ("bunch", (7, 0.9, 0.7, 0.2, 0, 0.5, 0.1, 1)),
    "green onion": ("bunch", (32, 1.8, 7.3, 0.2, 0, 2.6, 2.3, 16)),
    "cucumber": ("each", (45, 2, 11, 0.3, 0.1, 1.5, 5, 6)),
    "zucchini": ("each", (33, 2.4, 6, 0.6, 0.2, 2, 5, 16)),
    "eggplant": ("each", (115, 4.5, 27, 0.8, 0.2, 14, 16, 9)),
    "carrot": ("each", (25, 0.6, 6, 0.1, 0, 1.7, 2.9, 42)),
    "celery": ("stalk", (6, 0.3, 1.2, 0.1, 0, 0.6, 0.5, 32)),
    "potato": ("each", (164, 4.3, 37, 0.2, 0.1, 2.6, 1.3, 13)),
    "sweet potato": ("each", (112, 2, 26, 0.1, 0, 3.9, 5.4, 72)),
    "cabbage": ("head", (225, 11.5, 52, 0.9, 0.3, 22, 29, 160)),
    "romaine": ("head", (105, 7.6, 20, 2, 0.3, 13, 7, 50)),
    "butter lettuce": ("head", (45, 4.5, 8, 0.8, 0.1, 4, 2, 20)),
    "broccoli": ("head", (100, 8.5, 20, 1.1, 0.2, 7.8, 5, 100)),
    "cauliflower": ("head", (145, 11, 29, 1.6, 0.4, 11.5, 11, 173)),
    "spinach": ("oz", (6.5, 0.8, 1, 0.1, 0, 0.6, 0.1, 22)),
    "kale": ("oz", (14, 0.8, 2.5, 0.2, 0, 1, 0.3, 11)),
    "collard greens": ("lb", (145, 14, 25, 3, 0.4, 18, 2, 90)),
    "bok choy": ("lb", (60, 7, 10, 1, 0.1, 4.5, 5, 290)),
    "green beans": ("lb", (140, 8, 32, 1, 0.2, 12, 15, 27)),
    "asparagus": ("lb", (90, 10, 18, 0.5, 0.2, 9.5, 8.5, 9)),
    "mushroom": ("oz", (6, 0.9, 0.9, 0.1, 0, 0.3, 0.6, 1.4)),
    "okra": ("lb", (150, 9, 32, 0.9, 0.2, 14, 7, 30)),
    "corn": ("cup", (125, 4.5, 30, 1, 0.2, 3, 4.5, 5)),
    "peas": ("cup", (117, 8, 21, 0.6, 0.1, 7.4, 8, 108)),
    "mixed vegetables": ("cup", (107, 5, 22, 0.2, 0, 7, 5, 64)),
    "cauliflower rice": ("cup", (25, 2, 5, 0.3, 0, 2, 2, 30)),  # frozen
    "banana": ("each", (105, 1.3, 27, 0.4, 0.1, 3.1, 14, 1)),
    "apple": ("each", (95, 0.5, 25, 0.3, 0, 4.4, 19, 2)),
    "blueberries": ("cup", (84, 1.1, 21, 0.5, 0, 3.6, 15, 1)),
    "strawberries": ("cup", (49, 1, 11.7, 0.5, 0, 3, 7.4, 1.5)),
    "frozen berries": ("cup", (70, 1, 17, 0.4, 0, 4, 11, 1)),
}


def zero() -> dict[str, float]:
    return {k: 0.0 for k in NUTRIENTS}


def facts_for(name: str, unit: str) -> tuple[float, ...] | None:
    """Nutrients for one `unit` of an ingredient, or None if unknown."""
    key = name.lower().strip()
    entry = FACTS.get(key)
    if entry is None:
        # Longest pattern first, like the H-E-B mapping ("green onion" > "onion").
        for pattern in sorted(FACTS, key=len, reverse=True):
            if pattern in key:
                entry = FACTS[pattern]
                break
    if entry is None or entry[0] != unit:
        return None
    return entry[1]


def rounded(totals: dict[str, float]) -> dict[str, float]:
    """Label-style rounding: whole numbers, one decimal under 10 g."""
    out = {}
    for k, v in totals.items():
        out[k] = round(v) if k in ("calories", "sodium_mg") or v >= 10 else round(v, 1)
    return out


def per_serving(recipe: "Recipe", servings: float = 1.0) -> dict[str, float]:
    """Estimated nutrition for `servings` servings of a recipe."""
    totals = zero()
    for ing in recipe.ingredients:
        facts = facts_for(ing.name, ing.unit)
        if facts is None:
            continue
        for k, v in zip(NUTRIENTS, facts):
            totals[k] += v * ing.quantity
    factor = servings / (recipe.base_servings or 1)
    return rounded({k: v * factor for k, v in totals.items()})


def add(a: dict[str, float], b: dict[str, float]) -> dict[str, float]:
    return {k: a.get(k, 0) + b.get(k, 0) for k in NUTRIENTS}


def percent_dv(facts: dict[str, float]) -> dict[str, int]:
    return {k: round(100 * facts.get(k, 0) / dv) for k, dv in DAILY_VALUES.items()}
